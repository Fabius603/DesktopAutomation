# Drei Beispiel-Jobs für DesktopAutomation

1. Dateien sichern: kopiert den Inhalt eines Eingangsordners in einen getrennten Sicherungsordner und zeigt einen Hinweis an.
2. Arbeitsplatz vorbereiten: startet Editor und Rechner, anschließend erscheint eine Rückmeldung.
3. Nächsten Schritt auswählen: fragt eine von drei Antworten ab und zeigt die ausgewählte Antwort als Text auf dem Desktop.

## Einrichtung

Entpacke das Paket. Beende DesktopAutomation und kopiere die drei JSON-Dateien aus jobs in %APPDATA%\DesktopAutomation\Configs\Job. Bei einem eigenen Profil verwende %APPDATA%\DesktopAutomation\Profiles\PROFILNAME\Configs\Job. Starte die Anwendung erneut.

Dateien sichern: Kopiere den Ordner Beispieldaten/Eingang an einen eigenen Ort. Wähle diesen Ordner als Quelle und einen anderen, neuen Ordner als Ziel. Im Beispiel stehen C:\DesktopAutomation-Beispiele\Eingang und C:\DesktopAutomation-Beispiele\Sicherung. Verwende zum ersten Ausprobieren die mitgelieferten Testdateien. Bei einer erneuten Kopie können gleichnamige Dateien im Ziel ersetzt werden.

Arbeitsplatz vorbereiten: Prüfe die Programmpfade. Vorgesehen sind C:\Windows\System32\notepad.exe und C:\Windows\System32\calc.exe. Wähle auf deinem Rechner vorhandene Programme. Dieser Job öffnet die beiden Programme.

Nächsten Schritt auswählen: Stelle den Monitor im Auswahl- und Text-Schritt ein. Die Antwort wird angezeigt; die genannten Aufgaben werden nicht automatisch ausgeführt. Du kannst die Antwort später mit Bedingungen verbinden.

Die drei Jobs wurden mit dem Job-Serializer der Anwendung gespeichert, wieder eingelesen und mit JobValidation geprüft. Sie wurden für die Website in isolierten echten App-Ansichten gerendert. Sie wurden nicht auf dem Desktop ausgeführt. Prüfe Pfade und Einstellungen vor der Ausführung.
